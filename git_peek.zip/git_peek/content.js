let activeTooltip = null;
let hoverTimer = null;

// 1. Listen for mouseover events globally on the document
document.addEventListener("mouseover", (event) => {
  const target = event.target.closest("a");
  if (!target) return;

  const href = target.href;
  const githubRegex = /^https?:\/\/github\.com\/([a-zA-Z0-9_-]+)(?:\/)?$/;
  const match = href.match(githubRegex);

  if (match) {
    const username = match[1];
    
    // Store viewport-relative cursor coordinates for precise positioning
    const clientX = event.clientX;
    const clientY = event.clientY;
    const pageX = event.pageX;
    const pageY = event.pageY;

    hoverTimer = setTimeout(() => {
      fetchUserData(username, pageX, pageY, clientX, clientY);
    }, 500);
  }
});

// 2. Clear tooltip and cancel timer when mouse leaves
document.addEventListener("mouseout", (event) => {
  const target = event.target.closest("a");
  if (target && target.href && target.href.includes("github.com/")) {
    clearTimeout(hoverTimer);
    if (activeTooltip) {
      activeTooltip.remove();
      activeTooltip = null;
    }
  }
});

// 3. Request data from background script
function fetchUserData(username, pageX, pageY, clientX, clientY) {
  chrome.runtime.sendMessage(
    { action: "fetch_github_user", username },
    (response) => {
      if (response && response.success) {
        showTooltip(response.data, pageX, pageY, clientX, clientY);
      } else {
        showErrorTooltip(response ? response.error : "Unknown error", pageX, pageY, clientX, clientY);
      }
    }
  );
}

// Helper to calculate responsive screen bounds
function getResponsivePosition(pageX, pageY, clientX, clientY, cardWidth = 290, cardHeight = 220) {
  const padding = 15;
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  let left = pageX + padding;
  let top = pageY + padding;

  // If hovering near the right edge, shift card to the left of the cursor
  if (clientX + cardWidth + padding > viewportWidth) {
    left = pageX - cardWidth - padding;
  }

  // If hovering near the bottom edge, shift card above the cursor
  if (clientY + cardHeight + padding > viewportHeight) {
    top = pageY - cardHeight - padding;
  }

  return { left: Math.max(padding, left), top: Math.max(padding, top) };
}

// 4. Inject dynamic positioning preview card
function showTooltip(user, x, y, clientX, clientY) {
  if (activeTooltip) activeTooltip.remove();

  if (!document.getElementById("git-peek-styles")) {
    const style = document.createElement("style");
    style.id = "git-peek-styles";
    style.innerHTML = `
      @keyframes gitPeekFadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
      }

      @keyframes gitPeekRotateGradient {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      @keyframes gitPeekPulseGlow {
        0%, 100% { opacity: 0.8; filter: blur(12px); }
        50% { opacity: 1; filter: blur(18px); }
      }

      .git-peek-card-wrapper {
        position: absolute !important;
        z-index: 999999 !important;
        width: 290px !important;
        padding: 2px !important;
        border-radius: 16px !important;
        overflow: hidden !important;
        animation: gitPeekFadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
        box-shadow: 0 16px 40px rgba(0,0,0,0.8) !important;
      }

      .git-peek-card-wrapper::before {
        content: '' !important;
        position: absolute !important;
        top: -50% !important;
        left: -50% !important;
        width: 200% !important;
        height: 200% !important;
        background: conic-gradient(from 0deg, #ff007f, #7928ca, #0070f3, #00dfd8, #ff007f) !important;
        animation: gitPeekRotateGradient 4s linear infinite !important;
        z-index: 1 !important;
      }

      .git-peek-glow {
        position: absolute !important;
        top: -50% !important;
        left: -50% !important;
        width: 200% !important;
        height: 200% !important;
        background: conic-gradient(from 0deg, #ff007f, #7928ca, #0070f3, #00dfd8, #ff007f) !important;
        animation: gitPeekRotateGradient 4s linear infinite, gitPeekPulseGlow 3s ease-in-out infinite !important;
        z-index: 0 !important;
      }

      .git-peek-card-inner {
        position: relative !important;
        z-index: 2 !important;
        background: rgba(13, 17, 23, 0.88) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border-radius: 14px !important;
        padding: 16px !important;
        color: #f0f6fc !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
      }

      .git-peek-stat-box {
        flex: 1 !important;
        background: rgba(255, 255, 255, 0.05) !important;
        padding: 8px 10px !important;
        border-radius: 10px !important;
        text-align: center !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        transition: transform 0.2s ease !important;
      }

      .git-peek-stat-box:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        transform: translateY(-2px) !important;
      }
    `;
    document.head.appendChild(style);
  }

  const pos = getResponsivePosition(x, y, clientX, clientY, 290, 180);

  activeTooltip = document.createElement("div");
  activeTooltip.className = "git-peek-card-wrapper";
  activeTooltip.style.left = `${pos.left}px`;
  activeTooltip.style.top = `${pos.top}px`;

  const userBio = user.bio ? user.bio : "No bio available.";
  const userName = user.name || user.login;

  activeTooltip.innerHTML = `
    <div class="git-peek-glow"></div>
    <div class="git-peek-card-inner">
      <div style="display: flex; align-items: center; margin-bottom: 12px;">
        <img src="${user.avatar_url}" style="width: 48px; height: 48px; border-radius: 50%; margin-right: 12px; border: 2px solid #00dfd8; object-fit: cover; box-shadow: 0 0 12px rgba(0, 223, 216, 0.5);">
        <div style="overflow: hidden;">
          <div style="font-weight: 700; font-size: 14px; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; letter-spacing: 0.3px;">${userName}</div>
          <div style="font-size: 12px; color: #8b949e;">@${user.login}</div>
        </div>
      </div>
      <p style="font-size: 12px; line-height: 1.4; margin: 0 0 12px 0; color: #c9d1d9; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${userBio}</p>
      <div style="border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: 10px; display: flex; gap: 8px;">
        <div class="git-peek-stat-box">
          <div style="font-size: 10px; color: #8b949e; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 600;">Repos</div>
          <div style="font-weight: 700; color: #00dfd8; font-size: 14px; margin-top: 2px;">${user.public_repos}</div>
        </div>
        <div class="git-peek-stat-box">
          <div style="font-size: 10px; color: #8b949e; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 600;">Followers</div>
          <div style="font-weight: 700; color: #ff007f; font-size: 14px; margin-top: 2px;">${user.followers}</div>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(activeTooltip);
}

// 5. Error handling with boundary detection
function showErrorTooltip(errorMsg, x, y, clientX, clientY) {
  if (activeTooltip) activeTooltip.remove();

  const pos = getResponsivePosition(x, y, clientX, clientY, 200, 60);

  activeTooltip = document.createElement("div");
  activeTooltip.style.position = "absolute";
  activeTooltip.style.left = `${pos.left}px`;
  activeTooltip.style.top = `${pos.top}px`;
  activeTooltip.style.zIndex = "999999";
  activeTooltip.style.background = "linear-gradient(135deg, #da3633, #8e1f1d)";
  activeTooltip.style.color = "#fff";
  activeTooltip.style.padding = "10px 14px";
  activeTooltip.style.borderRadius = "8px";
  activeTooltip.style.fontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
  activeTooltip.style.fontSize = "12px";
  activeTooltip.style.boxShadow = "0 8px 24px rgba(0,0,0,0.5)";
  activeTooltip.innerText = `Git-Peek Error: ${errorMsg}`;

  document.body.appendChild(activeTooltip);
}